package com.akp.swarnmahasangh;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SelectionScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_screen);
    }
}