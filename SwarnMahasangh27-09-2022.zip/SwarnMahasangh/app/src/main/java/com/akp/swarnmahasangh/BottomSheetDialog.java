package com.akp.swarnmahasangh;


import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class BottomSheetDialog extends BottomSheetDialogFragment {

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable
            ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View v = inflater.inflate(R.layout.card_generate,
                container, false);

        ImageButton share_ib = v.findViewById(R.id.share_ib);
        ImageButton copy_ib = v.findViewById(R.id.copy_ib);
        ImageButton download_ib = v.findViewById(R.id.download_ib);
        ImageButton sharelink_ib = v.findViewById(R.id.sharelink_ib);
        RelativeLayout rl= v.findViewById(R.id.rl);
        rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent=new Intent(getActivity(),DashboardActivity.class);
                startActivity(intent);
                dismiss();
            }
        });
        share_ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent=new Intent(getActivity(),DashboardActivity.class);
                startActivity(intent);
                Toast.makeText(getActivity(),
                        "Whatsap Share", Toast.LENGTH_SHORT)
                        .show();
                dismiss();
            }
        });

        copy_ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            { Intent intent=new Intent(getActivity(),DashboardActivity.class);
                startActivity(intent);
                Toast.makeText(getActivity(),
                        "Copy Link", Toast.LENGTH_SHORT)
                        .show();
                dismiss();
            }
        });
        download_ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            { Intent intent=new Intent(getActivity(),DashboardActivity.class);
                startActivity(intent);
                Toast.makeText(getActivity(),
                        "Download", Toast.LENGTH_SHORT)
                        .show();
                dismiss();
            }
        });
        sharelink_ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            { Intent intent=new Intent(getActivity(),DashboardActivity.class);
                startActivity(intent);
                Toast.makeText(getActivity(),
                        "Share link", Toast.LENGTH_SHORT)
                        .show();
                dismiss();
            }
        });
        return v;
    }
}
